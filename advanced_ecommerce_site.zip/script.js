const productsRef = firebase.database().ref("products");
const productList = document.getElementById("productList");
const searchBox = document.getElementById("searchBox");
const categoryFilter = document.getElementById("categoryFilter");
let cart = JSON.parse(localStorage.getItem("cart")) || [];

function updateCartCount() {
  document.getElementById("cartCount").innerText = `Cart (${cart.length})`;
}
function addToCart(product) {
  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
}
function renderProducts(products) {
  productList.innerHTML = "";
  products.forEach(p => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = `
      <img src="${p.image}" />
      <h3>${p.name}</h3>
      <p>৳ ${p.price}</p>
      <button class="btn" onclick='addToCart(${JSON.stringify(p)})'>Add to Cart</button>
    `;
    productList.appendChild(div);
  });
}
function loadProducts() {
  productsRef.once("value", snapshot => {
    const data = snapshot.val();
    let products = Object.values(data);
    const keyword = searchBox.value.toLowerCase();
    const category = categoryFilter.value;

    products = products.filter(p => 
      (category === "all" || p.category === category) &&
      p.name.toLowerCase().includes(keyword)
    );
    renderProducts(products);
  });
}
searchBox.addEventListener("input", loadProducts);
categoryFilter.addEventListener("change", loadProducts);
window.onload = () => {
  updateCartCount();
  loadProducts();
};
